namespace MVCUppgift.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;

    internal sealed class Configuration : DbMigrationsConfiguration<MVCUppgift.Models.ProductModel>
    {
        public Configuration()
        {
            this.AutomaticMigrationDataLossAllowed = true;
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(MVCUppgift.Models.ProductModel context)
        {
            context.Products.AddOrUpdate(p => p.ID,
                //Bilar
                new Models.Product { ID = 1, Namn = "Volvo", Beskrivning = "Volvo XC90", Category_ID = 1, Pris = 490000 },
                new Models.Product { ID = 2, Namn = "Audi", Beskrivning = "A8", Category_ID = 1, Pris = 750000 },
                new Models.Product { ID = 3, Namn = "Mercedes", Beskrivning = "S-Class", Category_ID = 1, Pris = 980000 },
                new Models.Product { ID = 4, Namn = "Nissan", Beskrivning = "Qashqai+", Category_ID = 1, Pris = 289000 },
                new Models.Product { ID = 5, Namn = "BMW", Beskrivning = "5-Series", Category_ID = 1, Pris = 550000 },
                //Mobil
                new Models.Product { ID = 6, Namn = "Iphone", Beskrivning = "8 Plus", Category_ID = 2, Pris = 7500 },
                new Models.Product { ID = 7, Namn = "Iphone", Beskrivning = "XS MAX", Category_ID = 2, Pris = 17500 },
                new Models.Product { ID = 8, Namn = "Huawei", Beskrivning = "P20", Category_ID = 2, Pris = 8500 },
                new Models.Product { ID = 9, Namn = "Samsung", Beskrivning = "S9+", Category_ID = 2, Pris = 9990 },
                new Models.Product { ID = 10, Namn = "Samsung", Beskrivning = "Note9", Category_ID = 2, Pris = 15000 },
                //Mobil Tillbeh�r
                new Models.Product { ID = 11, Namn = "Laddare", Beskrivning = "Samsung USB-C Snabb Laddare", Category_ID = 3, Pris = 450 },
                new Models.Product { ID = 12, Namn = "Laddare", Beskrivning = "Iphone", Category_ID = 3, Pris = 400 },
                new Models.Product { ID = 13, Namn = "Skal", Beskrivning = "Iphone XS MAX Plast", Category_ID = 3, Pris = 270 },
                new Models.Product { ID = 14, Namn = "Skal", Beskrivning = "Note9 Rubber", Category_ID = 3, Pris = 250 },
                new Models.Product { ID = 15, Namn = "Skyddsglas", Beskrivning = "NovoX", Category_ID = 3, Pris = 400 },
                // Spel Konsoler
                new Models.Product { ID = 16, Namn = "Sony", Beskrivning = "PlayStation 4", Category_ID = 4, Pris = 3990 },
                new Models.Product { ID = 17, Namn = "Microsoft", Beskrivning = "Xbox One", Category_ID = 4, Pris = 3350 },
                new Models.Product { ID = 18, Namn = "Nintendo", Beskrivning = "Switch", Category_ID = 4, Pris = 3890 },
                new Models.Product { ID = 19, Namn = "Nvidia", Beskrivning = "Shield", Category_ID = 4, Pris = 2400 },
                new Models.Product { ID = 20, Namn = "Nintendo", Beskrivning = "NEW 2DS XL", Category_ID = 4, Pris = 1590 }
                );

            context.ProductCategories.AddOrUpdate(pc => pc.ID,
                new Models.Product_Category { ID = 1, Name = "Bilar" },
                new Models.Product_Category { ID = 2, Name = "Mobil" },
                new Models.Product_Category { ID = 3, Name = "Mobil Tillbeh�r" },
                new Models.Product_Category { ID = 4, Name = "Spel Konsoler" }
                );

            base.Seed(context);
            context.SaveChanges();
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
            //  to avoid creating duplicate seed data.
        }
    }
}
