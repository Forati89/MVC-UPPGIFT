namespace MVCUppgift.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class seed : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Products", "Product_Category_ID", c => c.Int());
            CreateIndex("dbo.Products", "Product_Category_ID");
            AddForeignKey("dbo.Products", "Product_Category_ID", "dbo.Product_Category", "ID");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Products", "Product_Category_ID", "dbo.Product_Category");
            DropIndex("dbo.Products", new[] { "Product_Category_ID" });
            DropColumn("dbo.Products", "Product_Category_ID");
        }
    }
}
