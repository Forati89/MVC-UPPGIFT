namespace MVCUppgift.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class UpdateAppUserModel : DbMigration
    {
        public override void Up()
        {
            Sql(@"ALTER TABLE AspNetUsers ADD RoleName varchar(255);");
        }
        
        public override void Down()
        {
        }
    }
}
