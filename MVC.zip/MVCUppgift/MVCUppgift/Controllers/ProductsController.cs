﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;
using Microsoft.Ajax.Utilities;
using MVCUppgift.Models;
using MVCUppgift.ViewModels;

namespace MVCUppgift.Controllers
{
    public class ProductsController : Controller
    {
        private ProductModel db = new ProductModel();

        // GET: Products
        public ActionResult Index()
        {
            var model = new ProductAndCatViewModel();
            using (var db = new Models.ProductModel())
            {
                model.Products.AddRange(db.Products.Select(p => new ViewModels.ProductAndCatViewModel.ProductListViewModel
                {
                    ID = p.ID,
                    Namn = p.Namn,
                    Beskrivning = p.Beskrivning,
                    Pris = p.Pris,
                    Category_ID = p.Category_ID

                }));

   
            }

            if (User.IsInRole("Admin") || User.IsInRole("ProductManager"))
                return View(model);

            return View("ReadOnly", model);
        }


        public ActionResult Details(int id)
        {

            using (var db = new ProductModel())
            {
                var product = db.Products.FirstOrDefault(p => p.ID == id);
                var model = new ProductViewModel()
                {
                    Namn = product.Namn,
                    Beskrivning = product.Beskrivning,
                    Pris = product.Pris,
                    Category_ID = product.Category_ID
                };
  
                
                return View(model);

            }
        }
        [HttpGet]
        public ActionResult Search(string Search)
        {
            var model = new ProductAndCatViewModel();

            using (var db = new ProductModel())
            {
                model.Products.AddRange(db.Products.Select(p => new ViewModels.ProductAndCatViewModel.ProductListViewModel
                {
                    ID = p.ID,
                    Namn = p.Namn,
                    Beskrivning = p.Beskrivning,
                    Pris = p.Pris,
                    Category_ID = p.Category_ID

                }).ToList().Where(p => p.Namn.ToLower().Contains(Search.ToLower()) || p.Beskrivning.ToLower().Contains(Search.ToLower()))
                );

                if (User.IsInRole("Admin") || User.IsInRole("ProductManager"))
                    return View("Index", model);

                return View("ReadOnly", model);
            }

            
        }
        [HttpGet]
        public ActionResult ProductsInCatergory(int id)
        {

            var model = new ProductAndCatViewModel();

            using (var db = new ProductModel())
            {
                model.Products.AddRange(db.Products.Select(p => new ProductAndCatViewModel.ProductListViewModel
                {
                    ID = p.ID,
                    Namn = p.Namn,
                    Beskrivning = p.Beskrivning,
                    Pris = p.Pris,
                    Category_ID = p.Category_ID
                }).ToList().Where(p => p.Category_ID == id));

            }
            if (User.IsInRole("Admin") || User.IsInRole("ProductManager"))
                return View("Index", model);

            return View("ReadOnly", model);

        }
        // GET: Products/Create
        [Authorize(Roles = "Admin, ProductManager")]
        public ActionResult Create()
        {
            var categories = db.ProductCategories.ToList();
            var viewModel = new NewProductViewModel
            {
                ProductCategories = categories
            };
            return View(viewModel);
        }

        // POST: Products/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin, ProductManager")]
        public ActionResult Create([Bind(Include = "ID,Namn,Beskrivning,Pris,Category_ID")] Product product)
        {
            var viewModel = new NewProductViewModel
            {
                Product = product,
                ProductCategories = db.ProductCategories.ToList()
            };
            if (product.ID == 0)
            {
                db.Products.Add(product);
            }
            else
            {
                var productInDB = db.Products.Single(p => p.ID == product.ID);
                productInDB.Namn = product.Namn;
                productInDB.Category_ID = product.Category_ID;
                productInDB.Beskrivning = product.Beskrivning;
                productInDB.Pris = product.Pris;

            }

            if (ModelState.IsValid)
            {
                
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View("Create", viewModel);
        }

        // GET: Products/Edit/5
        [Authorize(Roles = "Admin, ProductManager")]
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Product product = db.Products.Find(id);
            var viewModel = new NewProductViewModel
            {
                Product = product,
                ProductCategories = db.ProductCategories.ToList()
            };
            if (product == null)
            {
                return HttpNotFound();
            }
            return View(viewModel);
        }

        // POST: Products/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin, ProductManager")]
        public ActionResult Edit([Bind(Include = "ID,Namn,Beskrivning,Pris,Category_ID")] Product product)
        {
            var viewModel = new NewProductViewModel
            {
                Product = product,
                ProductCategories = db.ProductCategories.ToList()
            };
            if (product.ID == 0)
            {
                db.Products.Add(product);
            }
            else
            {
                var productInDB = db.Products.Single(p => p.ID == product.ID);
                productInDB.Namn = product.Namn;
                productInDB.Category_ID = product.Category_ID;
                productInDB.Beskrivning = product.Beskrivning;
                productInDB.Pris = product.Pris;

            }
            if (ModelState.IsValid)
            {
                //db.Entry(product).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(viewModel);
        }

        // GET: Products/Delete/5
        [Authorize(Roles = "Admin, ProductManager")]
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Product product = db.Products.Find(id);
            if (product == null)
            {
                return HttpNotFound();
            }
            return View(product);
        }

        // POST: Products/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin, ProductManager")]
        public ActionResult DeleteConfirmed(int id)
        {
            Product product = db.Products.Find(id);
            db.Products.Remove(product);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
