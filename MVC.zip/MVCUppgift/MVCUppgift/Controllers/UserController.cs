﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Net.Mime;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin.Security;
using MVCUppgift.Models;
using MVCUppgift.ViewModels;

namespace MVCUppgift.Controllers
{
    [Authorize(Roles = "Admin")]
    public class UserController : Controller
    {
        private ApplicationUserManager _UserManager;
        private ApplicationSignInManager _SignInManager;

        public ApplicationDbContext context = new ApplicationDbContext();

        public ActionResult UserList()
        {
            var context = new ApplicationDbContext();

            var usersWithRoles = (from user in context.Users
                                  select new
                                  {

                                      Username = user.UserName,
                                      Id = user.Id,
                                      Email = user.Email,
                                      RoleNames = (from userRole in user.Roles
                                                   join role in context.Roles on userRole.RoleId equals role.Id
                                                   select role.Name).ToList()
                                  }).ToList().Select(p => new UserViewModel()

                                  {
                                      Username = p.Username,
                                      Email = p.Email,
                                      Role = string.Join(",", p.RoleNames),
                                      Id = p.Id
                                  }).ToList();

            return View(usersWithRoles);
            //context.Users.ToList()
        }

        public ActionResult UserDelete(string id)
        {
            var context = new ApplicationDbContext();
            var user = context.Users.FirstOrDefault(u => u.Id == id);
            return View(user);
        }

        [HttpPost]
        public ActionResult UserDelete(ApplicationUser appuser)
        {
            var context = new ApplicationDbContext();
            var user = context.Users.FirstOrDefault(u => u.Id == appuser.Id);
            context.Users.Remove(user);
            context.SaveChanges();
            //var user = context.Users.Where(u => u.Id == id.ToString()).FirstOrDefault();
            return RedirectToAction("UserList");
        }



        public ActionResult UserEdit(string id)
        {
            var context = new ApplicationDbContext();
            ViewBag.RoleName = new SelectList(context.Roles.Where(u => u.Name.Contains(""))
                .ToList(), "Name", "Name");

            var user = context.Users.FirstOrDefault(u => u.Id == id);


            return View(user);
        }

        [HttpPost]
        public ActionResult UserEdit(ApplicationUser appuser, string RoleName)
        {
            var context = new ApplicationDbContext();
            var user = context.Users.FirstOrDefault(u => u.Id == appuser.Id);
            var UserManager = new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(context));
            if (user.Roles.Count == 0)
            {
                UserManager.AddToRole(user.Id, RoleName);
                context.SaveChanges();
                return RedirectToAction("UserList");

            }

                var oldRoleId = user.Roles.SingleOrDefault().RoleId;

                var oldRoleName = context.Roles.SingleOrDefault(r => r.Id == oldRoleId).Name;

                if (oldRoleName != RoleName)
                {

                    UserManager.RemoveFromRole(user.Id, oldRoleName);
                    UserManager.AddToRole(user.Id, RoleName);
                }

                //if (oldRoleId == null)
                //{
                //    UserManager.AddToRole(user.Id, RoleName);
                //}
                context.Entry(user).State = EntityState.Modified;
                //context.Entry(appuser).State = EntityState.Modified;
                user.Email = appuser.Email;
                user.UserName = appuser.UserName;
                user.PhoneNumber = appuser.PhoneNumber;
                user.PasswordHash = user.PasswordHash;
                context.SaveChanges();
                //var user = context.Users.Where(u => u.Id == id.ToString()).FirstOrDefault();
            return RedirectToAction("UserList");

        }
    }
}
