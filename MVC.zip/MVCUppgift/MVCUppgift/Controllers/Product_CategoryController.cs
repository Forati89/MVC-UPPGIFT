﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using MVCUppgift.Models;
using MVCUppgift.ViewModels;

namespace MVCUppgift.Controllers
{
    public class Product_CategoryController : Controller
    {
        private ProductModel db = new ProductModel();

        [HttpGet]
        public ActionResult Index()
        {
            var model = new CategoryViewModel();
            using (var db = new Models.ProductModel())
            {
                model.Category.AddRange(db.ProductCategories.Select(p => new ViewModels.CategoryViewModel.CategoryListViewModel
                {
                    ID = p.ID,
                    Namn = p.Name

                }));
            }


            if (User.IsInRole("Admin") || User.IsInRole("ProductManager"))
                return View(model);

            return View("ReadOnly",model);

        }


        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Product_Category product_Category = db.ProductCategories.Find(id);
            if (product_Category == null)
            {
                return HttpNotFound();
            }
            return View(product_Category);
        }
        [Authorize(Roles = "Admin, ProductManager")]
        public ActionResult Create()
        {
            return View();
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin, ProductManager")]
        public ActionResult Create([Bind(Include = "ID,Name")] Product_Category product_Category)
        {
            if (ModelState.IsValid)
            {
                db.ProductCategories.Add(product_Category);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(product_Category);
        }

        [Authorize(Roles = "Admin, ProductManager")]
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Product_Category product_Category = db.ProductCategories.Find(id);
            if (product_Category == null)
            {
                return HttpNotFound();
            }
            return View(product_Category);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin, ProductManager")]
        public ActionResult Edit([Bind(Include = "ID,Name")] Product_Category product_Category)
        {
            if (ModelState.IsValid)
            {
                db.Entry(product_Category).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(product_Category);
        }
        [Authorize(Roles = "Admin, ProductManager")]
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Product_Category product_Category = db.ProductCategories.Find(id);
            if (product_Category == null)
            {
                return HttpNotFound();
            }
            return View(product_Category);
        }

        // POST: Product_Category/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin, ProductManager")]
        public ActionResult DeleteConfirmed(int id)
        {
            Product_Category product_Category = db.ProductCategories.Find(id);
            db.ProductCategories.Remove(product_Category);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
        
    }
}
