﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MVCUppgift.Models;

namespace MVCUppgift.ViewModels
{
    public class NewProductViewModel
    {
        public IEnumerable<Product_Category> ProductCategories { get; set; }
        public Product Product { get; set; }
    }
}