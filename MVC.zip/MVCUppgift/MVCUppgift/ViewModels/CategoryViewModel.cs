﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MVCUppgift.Models;

namespace MVCUppgift.ViewModels
{
    public class CategoryViewModel
    {

        public CategoryViewModel()
        {
            Category = new List<CategoryListViewModel>();
        }
        public class CategoryListViewModel
        {
            public int ID { get; set; }
            public string Beskrivning { get; set; }
            public string Namn { get; set; }

        }
        public List<CategoryListViewModel> Category { get; set; }
    }
}