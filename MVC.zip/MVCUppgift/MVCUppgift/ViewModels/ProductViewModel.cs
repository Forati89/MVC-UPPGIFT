﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.AccessControl;
using System.Web;

namespace MVCUppgift.ViewModels
{
    public class ProductViewModel
    {
        public int ID { get; set; }
        public string Namn { get; set; }
        public string Beskrivning { get; set; }
        public decimal Pris { get; set; }
        public int Category_ID { get; set; }

    }
}