﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVCUppgift.Models
{
    public class CatListModel
    {

        public static List<SelectListItem> CatList()
        {
            ProductModel db = new ProductModel();
            List<SelectListItem> List = new List<SelectListItem>();
            var catProps = from c in db.ProductCategories select c;

            foreach (var category in catProps)
            {
                List.Add(new SelectListItem { Text = category.Name, Value = category.ID.ToString() });

            }
            return List;
        }
    }
}