﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVCUppgift.Models
{
    public class Product
    {
        [Required]
        public int ID { get; set; }
        [MaxLength(255)]
        public string Namn { get; set; }
        [MaxLength(500)]
        public string Beskrivning { get; set; }
        public decimal Pris { get; set; }
        [Display(Name = "Kategori")]
        public int Category_ID { get; set; }
    }
}