﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MVCUppgift.Models
{
    public class EditUserViewModel
    {
        public EditUserViewModel() { }

        // Allow Initialization with an instance of ApplicationUser:
        public EditUserViewModel(ApplicationUser user)
        {
            this.UserName = user.UserName;
            this.Email = user.Email;
            this.Password = user.PasswordHash;
            this.RoleName = user.Roles.ToString();
            this.Id = user.Id;
        }

        public string Id { get; set; }
        public string RoleName { get; set; }
        [Required]
        [Display(Name = "User Name")]
        public string UserName { get; set; }

        public string Password { get; set; }
        [Required]
        public string Email { get; set; }

        //you might want to implement jobs too, if you want to display them in your index view
    }
}
